import cv2
import numpy as np
from flask import Flask, render_template, request, send_file
from io import BytesIO

app = Flask(__name__)

#function to convert data into binary
def to_bin(data):
    if isinstance(data,str):
        return ''.join([format(ord(i),"08b") for i in data])
    elif isinstance(data,bytes):
        return ''.join([format(i,"08b") for i in data])
    elif isinstance(data,np.ndarray):
        return [format(i,"08b") for i in data]
    elif isinstance(data,int):
        return format(data,"08b")
    else:
        raise TypeError("Type not supported.")

#function for hiding text in image
def encode(image_name, secret_data):
    # read the image
    image = cv2.imread(image_name)
    print("[*]Encoding data...")
    secret_data += "===="
    index = 0
    binary_secret_data = to_bin(secret_data)
    for row in image:
        for pixel in row:
            r, g, b = to_bin(pixel)
            if index < len(binary_secret_data):
                pixel[0] = int(r[:-1] + binary_secret_data[index], 2)
                index += 1
            if index < len(binary_secret_data):
                pixel[1] = int(g[:-1] + binary_secret_data[index], 2)
                index += 1
            if index < len(binary_secret_data):
                pixel[2] = int(b[:-1] + binary_secret_data[index], 2)
                index += 1
            if index >= len(binary_secret_data):  
                break
    return image


#function to decode the hided text from image
def decode(image_name):
    print("[+] Decoding...")
    image= cv2.imread(image_name)
    binary_data=""
    for row in image:
        for pixel in row:
            r,g,b= to_bin(pixel)
            binary_data +=r[-1]
            binary_data +=g[-1]
            binary_data +=b[-1]
    all_bytes = [binary_data[i:i+8]for i in range(0,len(binary_data),8)]
    decoded_data=""
    for byte in all_bytes:
        decoded_data += chr(int(byte,2))
        if decoded_data[-4:] == "====":
            break
    return decoded_data[:-4]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/encode', methods=['POST'])
def encode_view():
    if request.method == 'POST':
        image = request.files['image']
        secret_data = request.form['secret_data']

        # Save the uploaded image
        image_path = "uploads/input_image.png"
        image.save(image_path)

        # Encode the image
        encoded_image = encode(image_name=image_path, secret_data=secret_data)

        # Save the encoded image
        output_path = "uploads/encoded_image.png"
        cv2.imwrite(output_path, encoded_image)

        return send_file(output_path, as_attachment=True)

@app.route('/decode', methods=['POST', 'GET'])
def decode_view():
    decoded_data = None
    if request.method == 'POST':
        encoded_image = request.files['encoded_image']

        # Save the uploaded encoded image
        encoded_image_path = "uploads/encoded_image_to_decode.png"
        encoded_image.save(encoded_image_path)

        # Decode the image
        decoded_data = decode(image_name=encoded_image_path)

    return render_template('index.html', decoded_data=decoded_data)

if __name__ == "__main__":
    app.run(debug=True)
